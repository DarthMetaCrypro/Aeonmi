# GHOST MODE v1 - Design System

## Design Philosophy

### Visual Language
- **Quantum Uncertainty**: Visual elements that suggest observation changes reality
- **Ephemeral Nature**: Designs that fade, glitch, and disappear
- **Technical Precision**: Clean, minimalist interfaces with surgical focus
- **Cyberpunk Aesthetic**: Dark, neon-accented, futuristic without being cheesy

### Color Palette
- **Primary**: Deep Black (#0a0a0a) - represents the void, zero-trace
- **Quantum Blue**: Electric Blue (#00d4ff) - quantum states, living keys
- **Ghost Purple**: Vibrant Purple (#8b5cf6) - quantum tunneling, encryption
- **Warning Orange**: Orange (#ff6b35) - 7-second countdown, self-destruct
- **Terminal Green**: Green (#00ff41) - successful operations, CLI output
- **Text**: Pure White (#ffffff) and Light Gray (#e5e7eb)

### Typography
- **Display Font**: "JetBrains Mono" - monospace for terminal authenticity
- **Body Font**: "Inter" - clean, modern sans-serif for readability
- **Accent Font**: "Orbitron" - futuristic for headings and quantum elements

## Visual Effects

### Used Libraries
- **Anime.js**: Smooth animations and transitions
- **p5.js**: Quantum particle systems and generative backgrounds
- **PIXI.js**: High-performance visual effects and shaders
- **Splitting.js**: Text animation effects for quantum glitching
- **Typed.js**: Terminal-style text typing effects

### Effect Implementations

#### 1. Quantum Particle Background
- **Technology**: p5.js with custom particle system
- **Behavior**: Particles that collapse when cursor approaches (observer effect)
- **Colors**: Quantum blue and ghost purple with transparency
- **Physics**: Brownian motion with quantum uncertainty principles

#### 2. Glitch Text Effects
- **Technology**: Splitting.js + Anime.js
- **Behavior**: Text glitches and distorts on hover/quantum events
- **Timing**: Random intervals to simulate quantum uncertainty
- **Intensity**: Subtle, not overwhelming

#### 3. Terminal Simulator
- **Technology**: Custom JavaScript with Typed.js
- **Behavior**: Authentic command-line interface with quantum commands
- **Animation**: Cursor blinking, text typing, command execution
- **Effects**: Quantum key generation with visual feedback

#### 4. Glyph Atlas Animation
- **Technology**: CSS transforms + Anime.js
- **Behavior**: Glyphs glow, rotate, and respond to interaction
- **Hover Effects**: 3D tilt, glow expansion, quantum particle emission
- **Click Feedback**: Ripple effects with quantum color cycling

#### 5. Quantum Hash Visualization
- **Technology**: PIXI.js with shader effects
- **Behavior**: Living hash that pulses and changes based on quantum state
- **Collapse Animation**: Dramatic dissipation when "observed"
- **Regeneration**: New hash appears with particle birth effect

### Header Effect
- **Quantum Tunnel Visualization**: Animated tunnel with flowing particles
- **Depth Parallax**: Multiple layers creating depth illusion
- **Color Cycling**: Smooth transitions through quantum color palette
- **Responsive**: Adapts to screen size while maintaining effect

### Scroll Motion
- **Quantum Entanglement**: Elements move in correlated patterns
- **Fade-in Timing**: Elements appear as if being "observed"
- **Parallax Layers**: Background moves at different speeds
- **Glitch Reveals**: Content appears with brief digital distortion

## Layout Principles

### Grid System
- **Base**: 12-column CSS Grid with quantum-inspired proportions
- **Breakpoints**: Mobile-first responsive design
- **Spacing**: Fibonacci sequence for natural, organic feel

### Content Hierarchy
- **Primary**: GHOST MODE title and quantum key generator
- **Secondary**: Glyph atlas and CLI simulator
- **Tertiary**: Technical specifications and patent information

### Interactive Zones
- **Quantum Lab**: Center area for key generation and experiments
- **Terminal Bay**: Bottom section for CLI interactions
- **Patent Archive**: Side panel for technical documentation
- **Glyph Matrix**: Dedicated space for symbol exploration

## Technical Implementation

### CSS Architecture
- **Custom Properties**: Quantum color palette as CSS variables
- **Grid Layout**: Modern CSS Grid for complex layouts
- **Flexbox**: For component-level alignment
- **Transforms**: 3D effects for quantum illusions

### Performance Considerations
- **Lazy Loading**: Effects initialize when elements enter viewport
- **GPU Acceleration**: Use transform3d for smooth animations
- **Frame Rate**: Target 60fps with requestAnimationFrame
- **Memory Management**: Clean up particles and effects properly

### Accessibility
- **Reduced Motion**: Respect user preferences
- **High Contrast**: Alternative color schemes
- **Keyboard Navigation**: Full keyboard support
- **Screen Readers**: Proper ARIA labels for quantum states