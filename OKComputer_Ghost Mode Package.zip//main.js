// GHOST MODE v1 - Main JavaScript
// Quantum-guarded ephemeral interactions

class QuantumSystem {
    constructor() {
        this.quantumKeys = [];
        this.isObserved = false;
        this.countdown = 7.00;
        this.particles = [];
        this.init();
    }
    
    init() {
        this.setupQuantumParticles();
        this.setupTypedText();
        this.setupScrollAnimations();
        this.startQuantumCountdown();
        this.setupGlitchEffects();
    }
    
    setupQuantumParticles() {
        // Create quantum particle system using p5.js
        const sketch = (p) => {
            let particles = [];
            const numParticles = 100;
            
            p.setup = () => {
                const canvas = p.createCanvas(p.windowWidth, p.windowHeight);
                canvas.parent('quantumParticles');
                canvas.style('position', 'fixed');
                canvas.style('top', '0');
                canvas.style('left', '0');
                canvas.style('z-index', '-1');
                canvas.style('pointer-events', 'none');
                
                // Initialize particles
                for (let i = 0; i < numParticles; i++) {
                    particles.push({
                        x: p.random(p.width),
                        y: p.random(p.height),
                        vx: p.random(-1, 1),
                        vy: p.random(-1, 1),
                        size: p.random(2, 6),
                        alpha: p.random(0.3, 0.8),
                        color: p.random(['#00d4ff', '#8b5cf6', '#00ff41']),
                        life: p.random(100, 300),
                        maxLife: p.random(100, 300)
                    });
                }
            };
            
            p.draw = () => {
                p.clear();
                
                // Update and draw particles
                for (let i = particles.length - 1; i >= 0; i--) {
                    const particle = particles[i];
                    
                    // Update position with quantum uncertainty
                    particle.x += particle.vx + p.random(-0.5, 0.5);
                    particle.y += particle.vy + p.random(-0.5, 0.5);
                    
                    // Update life
                    particle.life--;
                    
                    // Quantum observer effect
                    const mouseDistance = p.dist(p.mouseX, p.mouseY, particle.x, particle.y);
                    if (mouseDistance < 100) {
                        particle.alpha *= 0.95; // Collapse when observed
                        particle.vx += p.random(-2, 2);
                        particle.vy += p.random(-2, 2);
                    }
                    
                    // Respawn dead particles
                    if (particle.life <= 0 || particle.alpha < 0.01) {
                        particles[i] = {
                            x: p.random(p.width),
                            y: p.random(p.height),
                            vx: p.random(-1, 1),
                            vy: p.random(-1, 1),
                            size: p.random(2, 6),
                            alpha: p.random(0.3, 0.8),
                            color: p.random(['#00d4ff', '#8b5cf6', '#00ff41']),
                            life: p.random(100, 300),
                            maxLife: p.random(100, 300)
                        };
                    }
                    
                    // Draw particle
                    p.fill(particle.color + Math.floor(particle.alpha * 255).toString(16).padStart(2, '0'));
                    p.noStroke();
                    p.ellipse(particle.x, particle.y, particle.size);
                    
                    // Draw connections
                    for (let j = i + 1; j < particles.length; j++) {
                        const other = particles[j];
                        const distance = p.dist(particle.x, particle.y, other.x, other.y);
                        if (distance < 150) {
                            const alpha = (1 - distance / 150) * particle.alpha * 0.5;
                            p.stroke(particle.color + Math.floor(alpha * 255).toString(16).padStart(2, '0'));
                            p.strokeWeight(0.5);
                            p.line(particle.x, particle.y, other.x, other.y);
                        }
                    }
                }
            };
            
            p.windowResized = () => {
                p.resizeCanvas(p.windowWidth, p.windowHeight);
            };
        };
        
        new p5(sketch);
    }
    
    setupTypedText() {
        const typed = new Typed('#typed-subtitle', {
            strings: [
                'Quantum-guarded ephemeral CLI shard',
                'Ephemeral packet tunnel with living quantum hash',
                'Zero-trace networking in 847 bytes',
                '7-second half-life, no survivors'
            ],
            typeSpeed: 50,
            backSpeed: 30,
            backDelay: 2000,
            loop: true,
            showCursor: true,
            cursorChar: '_'
        });
    }
    
    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, observerOptions);
        
        document.querySelectorAll('.fade-in').forEach(el => {
            observer.observe(el);
        });
    }
    
    setupGlitchEffects() {
        const glitchElements = document.querySelectorAll('.quantum-glitch');
        
        glitchElements.forEach(element => {
            setInterval(() => {
                if (Math.random() < 0.1) { // 10% chance for glitch
                    element.style.transform = `translate(${Math.random() * 4 - 2}px, ${Math.random() * 4 - 2}px)`;
                    setTimeout(() => {
                        element.style.transform = 'none';
                    }, 100);
                }
            }, 100);
        });
    }
    
    generateQuantumKey() {
        const keyElement = document.getElementById('quantumKey');
        const characters = '0123456789abcdef';
        let newKey = '⊙0x';
        
        // Generate quantum-random hash
        for (let i = 0; i < 16; i++) {
            newKey += characters[Math.floor(Math.random() * characters.length)];
        }
        
        // Animate key generation
        anime({
            targets: keyElement,
            scale: [1, 1.1, 1],
            opacity: [1, 0.5, 1],
            duration: 500,
            easing: 'easeInOutQuad',
            complete: () => {
                keyElement.textContent = newKey;
                this.quantumKeys.push(newKey);
                
                // Add quantum pulse effect
                keyElement.classList.add('quantum-pulse');
                setTimeout(() => {
                    keyElement.classList.remove('quantum-pulse');
                }, 2000);
            }
        });
        
        // Reset countdown on key generation
        this.countdown = 7.00;
        this.isObserved = false;
    }
    
    startQuantumCountdown() {
        const countdownElement = document.getElementById('quantumCountdown');
        
        setInterval(() => {
            if (this.countdown > 0) {
                this.countdown -= 0.01;
                countdownElement.textContent = this.countdown.toFixed(2);
                
                // Add urgency effects when countdown is low
                if (this.countdown < 3) {
                    countdownElement.style.color = '#ff6b35';
                    countdownElement.style.textShadow = '0 0 30px rgba(255, 107, 53, 0.8)';
                } else {
                    countdownElement.style.color = '#ff6b35';
                    countdownElement.style.textShadow = '0 0 20px rgba(255, 107, 53, 0.5)';
                }
                
                // Collapse when countdown reaches zero
                if (this.countdown <= 0) {
                    this.collapseQuantumState();
                }
            }
        }, 10);
    }
    
    collapseQuantumState() {
        const keyElement = document.getElementById('quantumKey');
        
        // Animate collapse
        anime({
            targets: keyElement,
            scale: [1, 0],
            opacity: [1, 0],
            rotate: '360deg',
            duration: 1000,
            easing: 'easeInOutQuad',
            complete: () => {
                keyElement.textContent = '⊙STATE_COLLAPSED';
                keyElement.style.color = '#ff6b35';
                
                anime({
                    targets: keyElement,
                    scale: [0, 1],
                    opacity: [0, 1],
                    duration: 500,
                    easing: 'easeInOutQuad'
                });
            }
        });
        
        this.isObserved = true;
        
        // Auto-regenerate after collapse
        setTimeout(() => {
            this.generateQuantumKey();
        }, 3000);
    }
    
    spawnGhost() {
        const button = event.target;
        const originalText = button.textContent;
        
        // Animate button
        button.textContent = 'SPAWNING...';
        button.disabled = true;
        
        anime({
            targets: button,
            scale: [1, 0.95, 1],
            duration: 200,
            easing: 'easeInOutQuad',
            complete: () => {
                // Show ghost spawn animation
                this.showGhostSpawn();
                
                setTimeout(() => {
                    button.textContent = originalText;
                    button.disabled = false;
                }, 2000);
            }
        });
    }
    
    showGhostSpawn() {
        // Create ghost spawn notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-20 right-4 bg-black border border-blue-400 rounded-lg p-4 z-50';
        notification.innerHTML = `
            <div class="text-blue-400 font-mono text-sm">GHOST SPAWNED</div>
            <div class="text-white text-xs mt-1">Quantum tunnel active</div>
            <div class="text-gray-400 text-xs mt-1">TTL: 7.00s</div>
        `;
        
        document.body.appendChild(notification);
        
        // Animate notification
        anime({
            targets: notification,
            translateX: [300, 0],
            opacity: [0, 1],
            duration: 500,
            easing: 'easeOutQuad'
        });
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            anime({
                targets: notification,
                translateX: [0, 300],
                opacity: [1, 0],
                duration: 500,
                easing: 'easeInQuad',
                complete: () => {
                    document.body.removeChild(notification);
                }
            });
        }, 3000);
    }
}

// Glyph interaction system
class GlyphSystem {
    constructor() {
        this.glyphs = [
            { symbol: '⧉', name: 'Onion Array', desc: 'Array of onion relays' },
            { symbol: '⟨ ⟩', name: 'Exit Selector', desc: 'Pick exit node' },
            { symbol: '◈', name: 'Quantum Concat', desc: 'Concat quantum secret' },
            { symbol: '⟁', name: 'TTL Slicer', desc: 'Slice 7-second TTL' },
            { symbol: '‥', name: 'Separator', desc: 'Separation glyph' },
            { symbol: '⌁', name: 'Q-Mask', desc: 'Apply quantum mask' },
            { symbol: '⊙', name: 'Living Key', desc: 'Living key hash' },
            { symbol: '⚡', name: 'Energy Cap', desc: 'Energy cap 40 mW' },
            { symbol: '⟐', name: 'Left-Pipe', desc: 'Left-pipe to tunnel' },
            { symbol: '⸬', name: 'UDP Glue', desc: 'Glue UDP layers' },
            { symbol: '⹁', name: 'Reverse', desc: 'Reverse if censored' },
            { symbol: '⸮', name: 'No-Logs', desc: 'Compile-time assert' },
            { symbol: '⸟', name: 'Self-Destruct', desc: 'Quote self-destruct' },
            { symbol: '⸠', name: 'Entropy Spread', desc: 'Spread entropy' },
            { symbol: '⸡', name: 'Swap', desc: 'Swap entry/exit' },
            { symbol: '⸢', name: 'Quantum Lift', desc: 'Lift to quantum monad' },
            { symbol: '⸣', name: 'Classic Drop', desc: 'Drop back to classic' },
            { symbol: '⸤', name: 'Meta-Quote', desc: 'Meta-quote AST' },
            { symbol: '⸥', name: 'Runtime Eval', desc: 'Runtime eval' },
            { symbol: '⸪', name: 'FFI Link', desc: 'FFI link Tor/rustls' },
            { symbol: '⸫', name: 'Kill Switch', desc: 'Hardware kill switch' }
        ];
        
        this.setupGlyphInteractions();
    }
    
    setupGlyphInteractions() {
        document.querySelectorAll('.glyph-display').forEach((element, index) => {
            element.addEventListener('click', () => {
                this.showGlyphInfo(this.glyphs[index] || this.glyphs[0]);
            });
        });
    }
    
    showGlyphInfo(glyph) {
        // Create glyph info popup
        const popup = document.createElement('div');
        popup.className = 'fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50';
        popup.innerHTML = `
            <div class="bg-gray-900 border border-blue-400 rounded-lg p-8 max-w-md">
                <div class="text-6xl text-center mb-4">${glyph.symbol}</div>
                <div class="text-xl font-bold text-center mb-2 text-blue-400">${glyph.name}</div>
                <div class="text-gray-300 text-center mb-6">${glyph.desc}</div>
                <button onclick="this.parentElement.parentElement.remove()" 
                        class="quantum-button w-full">CLOSE</button>
            </div>
        `;
        
        document.body.appendChild(popup);
        
        // Animate popup
        anime({
            targets: popup.querySelector('div'),
            scale: [0, 1],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuad'
        });
    }
}

// Terminal simulator
class TerminalSimulator {
    constructor() {
        this.commands = {
            'ghost': this.spawnGhost.bind(this),
            'keygen': this.generateKey.bind(this),
            'status': this.showStatus.bind(this),
            'help': this.showHelp.bind(this)
        };
    }
    
    spawnGhost() {
        return {
            output: `Ghost spawned...
Quantum key: ⊙0x4f3a2b1c9d8e7f6a (living)
Exit: Reykjavik relay ⟨2⟩
TTL: 7.00s
Invoice paid. Streaming...
✓ 3 MB routed
Ghost extinguished. No trace.`,
            delay: 100
        };
    }
    
    generateKey() {
        return {
            output: `Generating quantum key...
⊙ Living hash: ⊙0x${Math.random().toString(16).substr(2, 16)}
Key active for 7 seconds
Quantum state: UNOBSERVED`,
            delay: 50
        };
    }
    
    showStatus() {
        return {
            output: `GHOST MODE v1 Status:
Binary size: 847 bytes
Quantum keys: Active
Tunnel status: Ephemeral
Memory footprint: Zero
Trace level: None`,
            delay: 30
        };
    }
    
    showHelp() {
        return {
            output: `GHOST MODE v1 Commands:
  ghost   - Spawn ephemeral tunnel
  keygen  - Generate quantum key
  status  - Show system status
  help    - Show this help

All commands leave zero trace after execution.`,
            delay: 20
        };
    }
}

// Initialize systems
let quantumSystem, glyphSystem, terminalSimulator;

document.addEventListener('DOMContentLoaded', () => {
    quantumSystem = new QuantumSystem();
    glyphSystem = new GlyphSystem();
    terminalSimulator = new TerminalSimulator();
});

// Global functions for HTML onclick handlers
function generateQuantumKey() {
    quantumSystem.generateQuantumKey();
}

function spawnGhost() {
    quantumSystem.spawnGhost();
}

// Utility functions
function createQuantumHash() {
    const chars = '0123456789abcdef';
    let hash = '⊙0x';
    for (let i = 0; i < 16; i++) {
        hash += chars[Math.floor(Math.random() * chars.length)];
    }
    return hash;
}

function addGlitchEffect(element) {
    element.style.filter = 'hue-rotate(180deg) saturate(2)';
    setTimeout(() => {
        element.style.filter = 'none';
    }, 100);
}

// Quantum state management
class QuantumState {
    static observe() {
        // Observing quantum state causes collapse
        if (window.quantumSystem) {
            quantumSystem.collapseQuantumState();
        }
    }
    
    static generate() {
        // Generate new quantum state
        if (window.quantumSystem) {
            quantumSystem.generateQuantumKey();
        }
    }
}

// Export for use in other pages
window.QuantumSystem = QuantumSystem;
window.GlyphSystem = GlyphSystem;
window.TerminalSimulator = TerminalSimulator;
window.QuantumState = QuantumState;